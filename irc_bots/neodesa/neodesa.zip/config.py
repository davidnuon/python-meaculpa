host = "irc.freenode.net"
port = 6667

botnick = "neodesabot"
botpass = ""
ident = "neodesabot"
realname = "neodesabot"
chan = ['#desaku','#grubbn']
mode = "" # Usually left blank

# ident lists

owner = "dn_desaku"
admin = [owner]
staff = ["a", "b"]

me  = ['dn_desaku', 'david', 'dave', 'master']
bot = ['desabot', 'myself', 'my_self']

defudeck = [
        'The Chainsaw Madman',
        'The Chuck Norris',
        'The Suicidal Bomber',
        'The Penguin',
        'The Paper',
        'The Rock',
        'The Nathangrubb',
        'The IRC Bot',
        'The Donut',
        'The Fireball',
        'The Cupcake',
        'The Fool',
        'The Lovers',
        'The Chariot',
        'The Empress',
        'The King',
        'The Bannana',
        'The PC',
        'The Blade',
        'The Poison',
        'The Cup',
        'The Death',
        'The Fly'
        ]